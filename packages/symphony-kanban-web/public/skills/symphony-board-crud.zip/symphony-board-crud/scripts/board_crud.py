#!/usr/bin/env python3
import argparse
import json
import sys
import urllib.error
import urllib.request
from typing import Any, Dict, Optional


def configure_utf8() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        # Fallback for older Pythons; still best-effort UTF-8 output
        pass


def build_url(base_url: str, path: str) -> str:
    if base_url.endswith("/"):
        base_url = base_url[:-1]
    if not path.startswith("/"):
        path = "/" + path
    return base_url + path


def request_json(
    method: str,
    url: str,
    data: Optional[Dict[str, Any]] = None,
) -> None:
    headers = {
        "Accept": "application/json; charset=utf-8",
    }
    body = None
    if data is not None:
        headers["Content-Type"] = "application/json; charset=utf-8"
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")

    req = urllib.request.Request(url, data=body, method=method.upper(), headers=headers)
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read()
            text = raw.decode("utf-8", errors="replace")
            try:
                payload = json.loads(text)
            except json.JSONDecodeError:
                print(text)
                return
            print(json.dumps(payload, ensure_ascii=False, indent=2))
    except urllib.error.HTTPError as err:
        raw = err.read()
        text = raw.decode("utf-8", errors="replace")
        print(f"HTTP {err.code} {err.reason}")
        if text:
            print(text)
        sys.exit(1)


def parse_tags(value: Optional[str]) -> Optional[list[str]]:
    if not value:
        return None
    tags = [t.strip() for t in value.split(",") if t.strip()]
    return tags or None


def cmd_list_boards(args: argparse.Namespace) -> None:
    url = build_url(args.base_url, "/boards")
    request_json("GET", url)


def cmd_list_columns(args: argparse.Namespace) -> None:
    url = build_url(args.base_url, f"/boards/{args.board_id}/columns")
    request_json("GET", url)


def cmd_list_workspaces(args: argparse.Namespace) -> None:
    url = build_url(args.base_url, "/workspaces")
    request_json("GET", url)


def cmd_create_issue(args: argparse.Namespace) -> None:
    payload: Dict[str, Any] = {
        "title": args.title,
        "workspace_id": args.workspace_id,
    }
    if args.description is not None:
        payload["description"] = args.description
    tags = parse_tags(args.tags)
    if tags is not None:
        payload["tags"] = tags
    url = build_url(args.base_url, "/issues")
    request_json("POST", url, payload)


def cmd_request(args: argparse.Namespace) -> None:
    data = None
    if args.data_file:
        with open(args.data_file, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    elif args.data:
        data = json.loads(args.data)
    url = build_url(args.base_url, args.path)
    request_json(args.method, url, data)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="SymphonyKanban board CRUD helper (API via Python, UTF-8 output)."
    )
    parser.add_argument(
        "--base-url",
        default="http://localhost:3001",
        help="API base URL (default: http://localhost:3001)",
    )

    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("list-boards", help="List all boards").set_defaults(
        func=cmd_list_boards
    )

    list_columns = sub.add_parser("list-columns", help="List columns for a board")
    list_columns.add_argument("--board-id", required=True, help="Board ID")
    list_columns.set_defaults(func=cmd_list_columns)

    sub.add_parser("list-workspaces", help="List workspaces").set_defaults(
        func=cmd_list_workspaces
    )

    create_issue = sub.add_parser(
        "create-issue", help="Create an issue with workspace + optional tags"
    )
    create_issue.add_argument("--title", required=True, help="Issue title")
    create_issue.add_argument(
        "--description", required=False, help="Issue description"
    )
    create_issue.add_argument(
        "--workspace-id", required=True, help="Workspace ID"
    )
    create_issue.add_argument(
        "--tags",
        required=False,
        help="Comma-separated tags (e.g., UserStory,Bugfix)",
    )
    create_issue.set_defaults(func=cmd_create_issue)

    request = sub.add_parser(
        "request",
        help="Send a raw request when endpoints need discovery",
    )
    request.add_argument("--method", required=True, help="HTTP method")
    request.add_argument("--path", required=True, help="API path, e.g. /boards")
    request.add_argument(
        "--data",
        required=False,
        help='Inline JSON string (e.g., "{\"name\":\"Sprint 1\"}")',
    )
    request.add_argument(
        "--data-file",
        required=False,
        help="Path to a JSON file for request body",
    )
    request.set_defaults(func=cmd_request)

    return parser


def main() -> None:
    configure_utf8()
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
