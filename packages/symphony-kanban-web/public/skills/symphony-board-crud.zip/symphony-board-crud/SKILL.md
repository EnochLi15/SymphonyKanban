---
name: symphony-board-crud
description: Use when asked to create, delete, update, or view SymphonyKanban boards, list board columns, or troubleshoot board management tasks via the Fizzy API/CLI in this repo.
---

# Symphony Board CRUD

## Overview

Use this skill to manage SymphonyKanban boards (create, read, update, delete) and to list board columns using the Fizzy API client and CLI tools already present in the repo.

## Quick Start

1. Prefer the existing Fizzy client and CLI first.
2. If the action is not supported, discover the API endpoints before writing new code.
3. Confirm destructive actions (delete) and the exact board ID before executing.

## Core Paths

### View Boards and Columns

**Fastest path:** use the CLI to list boards and columns.

```bash
pnpm -C /Users/enoch/Workspace/SymphonyKanban/packages/symphony-kanban-symphony/fizzy-popper \
  run fizzy-popper boards
```

**Programmatic path:** use `FizzyClient` from
`/Users/enoch/Workspace/SymphonyKanban/packages/symphony-kanban-symphony/fizzy-popper/src/fizzy.ts`.

```ts
import { FizzyClient } from "./fizzy.js"
import { loadConfig } from "./config.js"

const config = loadConfig()
const client = new FizzyClient(config)

const boards = await client.listBoards()
const columns = await client.listColumns(boards[0].id)
```

### Create a Board

1. Search for existing endpoints or helpers.
2. If no create endpoint exists, request API docs or use the product UI.

**Discovery step:**
```bash
rg -n "/boards" /Users/enoch/Workspace/SymphonyKanban/packages
```

**If a create endpoint exists**, add a `createBoard` method to `FizzyClient` and use it.  
Do not invent endpoints; confirm via docs or existing server code.

### Update a Board (Rename / Settings)

1. Locate update endpoints or server handlers for boards.
2. If missing, request docs or implement API support first.

**Discovery step:**
```bash
rg -n "boards|board" /Users/enoch/Workspace/SymphonyKanban/packages -g"*.ts"
```

**If an update endpoint exists**, add an `updateBoard` method to `FizzyClient`.

### Delete a Board

1. Confirm the board ID and name.
2. Check for soft-delete or archive semantics before deletion.

**Safety checklist:**
- Confirm board ID and name in the same response.
- Ask for explicit confirmation if the request is ambiguous.
- Prefer archive/soft-delete if the API supports it.

## Configuration and Auth

The Fizzy client reads from `.fizzy-popper/config.yml` via
`/Users/enoch/Workspace/SymphonyKanban/packages/symphony-kanban-symphony/fizzy-popper/src/config.ts`.

Config fields:
- `fizzy.api_url`
- `fizzy.account`
- `fizzy.token`

The config loader resolves environment variables that start with `$`, so secrets can be stored as env vars.

## Output Expectations

When listing or confirming actions:
- Provide a table with `board id`, `board name`, and `url`.
- For columns, include `column id` and `column name`.

When mutating:
- Echo the target board name + ID.
- Show the exact API call or function used.
- Confirm completion or error response.

## Common Mistakes

- Assuming create/update/delete endpoints exist without checking server code or API docs.
- Deleting a board when the system expects archive/close semantics.
- Mixing up board IDs between environments (dev vs prod).

## Example Requests This Skill Handles

- "列出所有看板并显示列信息"
- "新建一个叫 Sprint 43 的看板"
- "把 Board X 重命名为 Board Y"
- "删除 Board Z（如果只能归档也可以）"

