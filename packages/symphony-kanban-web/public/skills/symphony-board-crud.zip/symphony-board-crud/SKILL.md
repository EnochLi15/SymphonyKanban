---
name: symphony-board-crud
description: Use when asked to create, delete, update, or view SymphonyKanban boards, list board columns, or troubleshoot board management tasks via the SymphonyKanban API using the bundled Python script (no curl, no CLI).
---

# Symphony Board CRUD

## Overview

Use this skill to manage SymphonyKanban boards (create, read, update, delete), list board columns, list workspaces, and create tasks (issues) with workspace + tags using the HTTP API via the bundled Python script only (no curl, no CLI).

## Quick Start

1. Use the bundled Python script for all actions (no Fizzy CLI, no curl).
2. If the action is not supported, discover the API endpoints before writing new code.
3. Confirm destructive actions (delete) and the exact board ID before executing.

## Core Paths

### Script Usage

All calls go through:

```bash
python /Users/enoch/.agents/skills/symphony-board-crud/scripts/board_crud.py <command> [args]
```

For undiscovered endpoints, use the raw request command:

```bash
python /Users/enoch/.agents/skills/symphony-board-crud/scripts/board_crud.py \\
  request --method POST --path /boards --data '{\"name\":\"Sprint 43\"}'
```

### View Boards and Columns

**API path (Python script):** discover and use the board endpoints, then call them via `scripts/board_crud.py`.

```bash
python /Users/enoch/.agents/skills/symphony-board-crud/scripts/board_crud.py list-boards
```

**Columns (example):**
```bash
python /Users/enoch/.agents/skills/symphony-board-crud/scripts/board_crud.py \\
  list-columns --board-id <board_id>
```

### List Workspaces

**API path:** `GET /workspaces`

```bash
python /Users/enoch/.agents/skills/symphony-board-crud/scripts/board_crud.py list-workspaces
```

Returns `data: [{ id, name, localPath, context, createdAt, updatedAt }]`.

### Create a Task (Issue) With Workspace + Tags

**API path:** `POST /issues`

**Required:** `workspace_id` (string)

**Optional:** `tags` (string array)

```bash
python /Users/enoch/.agents/skills/symphony-board-crud/scripts/board_crud.py create-issue \\
  --title "Add onboarding checklist" \\
  --description "Define steps for first-time users" \\
  --workspace-id "wksp-123" \\
  --tags "UserStory"
```

If you need a workspace id first, call `GET /workspaces` and select one.

### Create a Board

1. Search for existing endpoints or helpers.
2. If no create endpoint exists, request API docs or use the product UI.

**Discovery step (API code):**
```bash
rg -n "/boards" /Users/enoch/Workspace/SymphonyKanban/packages
```

**If a create endpoint exists**, call it via the Python script using the `request` command.  
Do not invent endpoints; confirm via docs or existing server code.

### Update a Board (Rename / Settings)

1. Locate update endpoints or server handlers for boards.
2. If missing, request docs or implement API support first.

**Discovery step (API code):**
```bash
rg -n "boards|board" /Users/enoch/Workspace/SymphonyKanban/packages -g"*.ts"
```

**If an update endpoint exists**, call it via the Python script using the `request` command.

### Delete a Board

1. Confirm the board ID and name.
2. Check for soft-delete or archive semantics before deletion.

**Safety checklist:**
- Confirm board ID and name in the same response.
- Ask for explicit confirmation if the request is ambiguous.
- Prefer archive/soft-delete if the API supports it.

## Configuration and Auth

The Fizzy client reads from `.fizzy-popper/config.yml` via
`/Users/enoch/Workspace/SymphonyKanban/packages/symphony-kanban-symphony/fizzy-popper/src/config.ts`.

Config fields:
- `fizzy.api_url`
- `fizzy.account`
- `fizzy.token`

The config loader resolves environment variables that start with `$`, so secrets can be stored as env vars.

## UTF-8 Handling (乱码)

The bundled script forces UTF-8 output via `sys.stdout.reconfigure(encoding="utf-8")` and prints JSON with `ensure_ascii=False`.
If you still see garbled text, set:

```bash
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8
```

## Output Expectations

When listing or confirming actions:
- Provide a table with `board id`, `board name`, and `url`.
- For columns, include `column id` and `column name`.
- For workspaces, include `workspace id`, `workspace name`, and `localPath` (if present).

When mutating:
- Echo the target board name + ID.
- Show the exact script command used.
- Confirm completion or error response.

## Common Mistakes

- Assuming create/update/delete endpoints exist without checking server code or API docs.
- Deleting a board when the system expects archive/close semantics.
- Mixing up board IDs between environments (dev vs prod).
- Creating issues without `workspace_id` (API rejects it).

## Built-in Tags

There are **4** built-in tags, seeded at API startup:

- `UserStory`
- `Bugfix`
- `CodeReview`
- `Refactor`

You can pass any of the above in the `tags` array when creating an issue. Built-in tags are protected from deletion (`builtin_tag_protected`).

## Example Requests This Skill Handles

- "列出所有看板并显示列信息"
- "新建一个叫 Sprint 43 的看板"
- "把 Board X 重命名为 Board Y"
- "删除 Board Z（如果只能归档也可以）"
- "列出工作区并给我 ID"
- "在 workspace X 下新建任务并打上 UserStory 标签"
